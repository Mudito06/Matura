﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Panair_na_kiseloto_mlqko.Models
{
    public class Panair
    {
        public int Id { get; set; }
        public string Firma { get; set; }
        [Range(1,22)]
        public int NomerPavilion { get; set; }
        public TypeZanaqti TypeZanaqti { get; set; }
        public string Image { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }
}
