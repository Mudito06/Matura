﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Panair_na_kiseloto_mlqko.Models;

namespace Panair_na_kiseloto_mlqko.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Panair_na_kiseloto_mlqko.Models.Panair> Panair { get; set; }
    }
}
