﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Panair_na_kiseloto_mlqko.Models
{
    public enum  TypeZanaqti
    {
        Грънчарство, дървообработване, дърворезба, кожухарство
    }
}
